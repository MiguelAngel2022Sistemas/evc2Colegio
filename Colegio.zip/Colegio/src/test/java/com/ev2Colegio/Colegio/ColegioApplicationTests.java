package com.ev2Colegio.Colegio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioApplicationTests {

	@Test
	void contextLoads() {
	}

}
